#include "Task.h"
#include "TaskList.h"
#include <iostream>
#include <cassert>

int main()
{
    TaskList todos;

    auto test_time{ std::chrono::system_clock::now() };

    test_time += std::chrono::hours(24);

    Task task1{ "Buy a milk", Task::PRIORITY::NORMAL, test_time };

    todos.add_task(task1);
    assert(1 == todos.get_tasks_count()); // here adjusted assert function, replaced with 1

    test_time -= std::chrono::hours(48); // yesterday

    todos.add_task(Task{ "Buy a bread", Task::PRIORITY::HIGH, test_time });
    assert(todos.get_tasks_count() == 1 );

    std::cout << "All tasks\n====================\n";
    todos.send_to(std::cout);

    std::cout << "Due tasks\n====================\n";

    auto is_due{ [](auto&& task) { return task.is_due(); } };

    todos.send_to(std::cout, is_due);

    std::cout << "Completing 1st task ...\n\n";
    todos.complete_task(0);
    assert(!todos.task_is_due(0));

    std::cout << "Due tasks\n====================\n";
    todos.send_to(std::cout, is_due);

    todos.remove_done_tasks();
    assert(todos.get_tasks_count() == 0); // to be ensure of counting

    std::cout << "Press Return/Enter key...";
    std::cin.get();

    return 0;
}